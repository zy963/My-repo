import numpy as np
import math
import operator

file_path = 'C:\\Users\\Zheyi\\Documents\\CMU\\10601\\hw2\\handout\\small_train.tsv'
dataset = np.genfromtxt(file_path, delimiter="\t", dtype=None, encoding=None)


